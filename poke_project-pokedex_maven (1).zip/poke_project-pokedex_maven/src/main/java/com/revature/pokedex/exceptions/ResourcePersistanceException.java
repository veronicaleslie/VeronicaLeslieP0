package com.revature.pokedex.exceptions;

public class ResourcePersistanceException extends RuntimeException{

    public ResourcePersistanceException(String message) {
        super(message);
    }
}
